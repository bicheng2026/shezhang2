/**
 * 蛇杖二号 · 腾讯云云函数业务处理（SCF Web 函数 / 函数 URL）
 * ------------------------------------------------------------------
 * 接收 QQ 官方机器人 Webhook 回调（公网 HTTPS）→ 验签 → 脱敏 → 落库 → 提供手机页面。
 * 入口形如 https://{APPID}-{随机}.{region}.tencentscf.com（函数 URL，免备案、大陆可连通）
 *
 * 🔴 三个「必须这么写」的坑（都是线上实测踩出来的，改之前先读）：
 *
 * 1) **Node 运行时没有 WebCrypto 的 Ed25519**。
 *    SCF 的 Nodejs16.13：globalThis.crypto 是 undefined；require('crypto').webcrypto.subtle
 *    对 Ed25519 / Ed448 / X25519 **全部 NotSupportedError**。
 *    但**原生 crypto 模块支持**（generateKeyPairSync('ed25519') + sign 正常，签名 64 字节）。
 *    → Ed25519 一律走原生 createPrivateKey / createPublicKey，WebCrypto 只当回退。
 *
 * 2) **环境变量在 process.env**（不是 Web 平台的全局 env 对象）。
 *
 * 3) **存储层当前是内存 Map 兜底，重启丢数据**。生产要绑 CloudBase KV，
 *    换掉 KV() 里的实现即可（已留 setKV 注入口）。
 *
 * 路由：
 *   POST /          QQ Webhook 入口（/qq、/webhook 也认）
 *   POST /sync      本机推公告（Bearer ADMIN_TOKEN）
 *   GET  /health    自检
 *   GET  /probe     运行时能力探测（排错用）
 *   GET  /ann       公告 JSON（公开，带 CORS）
 *   GET  /qq?token= 群消息 JSON（私有，不开 CORS）
 *   GET  /page?kind=ann|qq&t=   手机页面（HTML）
 *   GET  /dbg?t=    排错口（含黑匣子）
 */

'use strict'
const _nc = require('crypto')

const CORS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400',
}
const HTML_HEADERS = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }

const IDX = { qq: 'idx_q', ann: 'idx_a' }
const IDX_MAX = 200
const PKCS8_PREFIX = '302e020100300506032b657004220420'   // Ed25519 私钥 pkcs8 头
const SPKI_PREFIX = '302a300506032b6570032100'           // Ed25519 公钥 spki 头

/* ==================== 存储层（待接 CloudBase KV） ==================== */
const _mem = new Map()
let _kv = null
function KV() {
  if (_kv) return _kv
  return {
    async get(k) { return _mem.has(k) ? _mem.get(k) : null },
    async put(k, v) { _mem.set(k, String(v)) },
    async list({ prefix, limit }) {
      return { keys: [..._mem.keys()].filter(x => x.startsWith(prefix)).sort().slice(0, limit).map(name => ({ name })) }
    },
  }
}
function setKV(o) { _kv = o }

async function kvPut(kind, id, obj) {
  const prefix = kind === 'ann' ? 'a/' : 'q/'
  const tail = (kind === 'ann' ? '' : 'qq_') + id
  const key = prefix + String(Date.now()) + '-' + tail.replace(/[^\w.-]/g, '_')
  await KV().put(key, JSON.stringify(obj))
  return key
}
async function bumpIndex(kind, item) {
  const key = IDX[kind]
  let arr = []
  try { const raw = await KV().get(key); arr = raw ? JSON.parse(raw) : [] } catch (e) { arr = [] }
  if (!Array.isArray(arr)) arr = []
  arr = arr.filter(x => x && x.id !== item.id)
  arr.push(item)
  arr.sort((a, b) => (Number(b.ts) || 0) - (Number(a.ts) || 0))
  arr = arr.slice(0, IDX_MAX)
  await KV().put(key, JSON.stringify(arr))
  return arr.length
}
async function readIndex(kind) {
  try {
    const raw = await KV().get(IDX[kind])
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch (e) { return [] }
}
/* 从 GitHub 摘要文件读回消息（云端重启后 KV 必丢，GitHub 才是持久层） */
async function readGhDigestItems(appid) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return []
  try {
    const cur = await ghGetFile(qqPathOf(appid), token, repo)
    if (!cur) return []
    const obj = JSON.parse(cur.content)
    const arr = Array.isArray(obj) ? obj : (obj.items || [])
    return (Array.isArray(arr) ? arr : []).map(x => ({
      ...x,
      ts: Number(x.ts) || (x.time ? Date.parse(x.time) : 0) || 0,
    }))
  } catch (e) { return [] }
}

async function listItems(kind, limit, appid) {
  let list = await readIndex(kind)
  if (!list.length) {
    const prefix = kind === 'ann' ? 'a/' : 'q/'
    try {
      const res = await KV().list({ prefix, limit: 50 })   // 只逐条取 50 条，别撞调用上限
      const keys = (res && (res.keys || res.list)) || []
      for (const k of keys) {
        const name = typeof k === 'string' ? k : k.name
        const raw = await KV().get(name)
        if (raw) { try { list.push(JSON.parse(raw)) } catch (e) { } }
      }
    } catch (e) { }
  }
  /* 🔴 云端重启后 KV 必丢（内存兜底）→ 群消息回落到 GitHub 持久层。
     不回落的话 /qq 返回空，pull_qq.py 的覆盖式 publish 会把 GitHub 上的真消息冲掉。
     2026-10-08：回落时**按 appid 取自己那份摘要**，绝不串班。 */
  if (!list.length && kind === 'qq') {
    list = await readGhDigestItems(appid)
  }
  list = list.slice().sort((a, b) =>
    (Number(b.ts) || Date.parse(b.time) || 0) - (Number(a.ts) || Date.parse(a.time) || 0))
  return list.slice(0, Math.min(limit, IDX_MAX))
}

/* ==================== 脱敏（顺序不能反：身份证 → 手机 → 学号） ==================== */
function scrub(t) {
  if (!t) return ''
  t = String(t)
    .replace(/<faceType=[^>]{0,160}>/g, '')
    .replace(/<@!?\d+>/g, '')
    .replace(/<face\w*[^>]*$/g, '')
  t = t.replace(/\b\d{17}[\dXx]\b/g, '[本人]')
  t = t.replace(/\b1[3-9]\d{9}\b/g, '[手机]')
  t = t.replace(/\b\d{10,12}\b/g, '[学号]')
  return t.trim()
}

/* ==================== 取值 ==================== */
function pick(o, keys) {
  if (!o || typeof o !== 'object') return undefined
  for (const k of keys) {
    const v = o[k]
    if (v !== undefined && v !== null && v !== '') return v
  }
  return undefined
}
function findKey(o, key, depth) {
  if (!o || typeof o !== 'object' || !depth) return undefined
  const v = o[key]
  if (v !== undefined && v !== null && (typeof v === 'string' || typeof v === 'number')) return v
  for (const k of Object.keys(o)) {
    // d 有时是「装着 JSON 的字符串」（官方 Go 用 json.RawMessage 解它），拆开再找
    if (typeof o[k] === 'string' && o[k].length < 4000 && /^[\s]*[{[]/.test(o[k])) {
      try { const r = findKey(JSON.parse(o[k]), key, depth - 1); if (r !== undefined) return r } catch (e) { }
    }
    const r = findKey(o[k], key, depth - 1)
    if (r !== undefined) return r
  }
  return undefined
}
function deepPick(o, keys, depth) {
  if (!o || typeof o !== 'object' || !depth) return undefined
  const v = pick(o, keys)
  if (v !== undefined) return v
  for (const k of Object.keys(o)) {
    const r = deepPick(o[k], keys, depth - 1)
    if (r !== undefined) return r
  }
  return undefined
}
function parseEvent(payload) {
  const d = (payload && payload.d) || {}
  const text = deepPick(d, ['content', 'msg', 'text', 'message', 'raw_message'], 3)
  if (text === undefined) return null
  return {
    text: String(text),
    gid: String(deepPick(d, ['group_id', 'group_openid', 'channel_id', 'guild_id'], 3) || ''),
    mid: String(deepPick(d, ['msg_id', 'id', 'event_id'], 3) || ''),
    ts: Number(deepPick(d, ['event_ts', 'ts', 'timestamp'], 3)) || Date.now(),
  }
}

/* ==================== Ed25519（走原生 crypto，见文件头坑 1） ==================== */
function hexClean(h) {
  const s = String(h || '').replace(/^0x/, '').trim()
  return s.length % 2 === 0 ? s : s.slice(0, -1)
}
function seedFromSecret(secret) {
  // 官方 Go 做法：botSecret 循环补到 ≥32 字节，再截前 32
  let seed = String(secret || '')
  while (Buffer.byteLength(seed, 'utf8') < 32) seed += String(secret || '')
  return Buffer.from(seed.slice(0, 32), 'utf8')
}
function privateKey(secret) {
  const der = Buffer.concat([Buffer.from(PKCS8_PREFIX, 'hex'), seedFromSecret(secret)])
  return _nc.createPrivateKey({ key: der, format: 'der', type: 'pkcs8' })
}
function publicKeyFromRaw(hex) {
  const der = Buffer.concat([Buffer.from(SPKI_PREFIX, 'hex'), Buffer.from(hexClean(hex), 'hex')])
  return _nc.createPublicKey({ key: der, format: 'der', type: 'spki' })
}
/* 2026-10-08：改为「按 appid 取 secret」——
   多机器人共存时必须用**这个机器人自己的**密钥，不能张冠李戴。
   传了 appid 就精确取；没传（老的 /dbg 之类）回落主机器人 → 环境变量。 */
async function signHex(msgStr, appid) {
  let secret = ''
  if (appid) {
    const r = botRec(appid)
    secret = (r && r.secret) || ''
    if (!secret) { try { secret = (await getBotCfg()).secret || '' } catch (e) { } }
  } else {
    try { secret = (await getBotCfg()).secret || '' } catch (e) { }
  }
  if (!secret) secret = process.env.BOT_SECRET || ''
  if (!secret) throw new Error('没配 BOT_SECRET（也没在网页上填过）')
  // 原生优先（Node16 的 WebCrypto 不支持 Ed25519）
  try {
    return _nc.sign(null, Buffer.from(String(msgStr), 'utf8'), privateKey(secret)).toString('hex')
  } catch (e) {
    console.log('[shezhang] 原生签名失败，试 WebCrypto：' + String((e && e.message) || e))
  }
  // 回退 WebCrypto（私钥必须 pkcs8 包装，raw seed 实测 import 会失败）
  const subtle = _nc.webcrypto && _nc.webcrypto.subtle
  if (!subtle) throw new Error('这个运行时既不能用原生 Ed25519，也没有 WebCrypto')
  const der = new Uint8Array(Buffer.concat([Buffer.from(PKCS8_PREFIX, 'hex'), seedFromSecret(secret)]))
  const key = await subtle.importKey('pkcs8', der, { name: 'Ed25519' }, false, ['sign'])
  const sig = await subtle.sign({ name: 'Ed25519' }, key, Buffer.from(String(msgStr), 'utf8'))
  return Buffer.from(sig).toString('hex')
}
async function verifyHex(hexSig, msgStr, appid) {
  let pubHex = ''
  if (appid) {
    const r = botRec(appid)
    pubHex = (r && r.pubkey) || ''
    if (!pubHex) { try { pubHex = (await getBotCfg()).pubkey || '' } catch (e) { } }
  } else {
    try { pubHex = (await getBotCfg()).pubkey || '' } catch (e) { }
  }
  if (!pubHex) pubHex = process.env.PUBKEY || ''
  if (!pubHex) return false
  try {
    return _nc.verify(null, Buffer.from(String(msgStr), 'utf8'),
      publicKeyFromRaw(pubHex), Buffer.from(hexClean(hexSig), 'hex'))
  } catch (e) {
    console.log('[shezhang] 原生验签失败，试 WebCrypto：' + String((e && e.message) || e))
  }
  const subtle = _nc.webcrypto && _nc.webcrypto.subtle
  if (!subtle) return false
  const key = await subtle.importKey('raw', Buffer.from(hexClean(pubHex), 'hex'),
    { name: 'Ed25519' }, false, ['verify'])
  return await subtle.verify({ name: 'Ed25519' }, key,
    Buffer.from(hexClean(hexSig), 'hex'), Buffer.from(String(msgStr), 'utf8'))
}

/* ==================== 页面渲染 ==================== */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
}
function fmtBj(ts) {
  const d = new Date((Number(ts) || Date.now()) + 8 * 3600 * 1000)
  const p = n => String(n).padStart(2, '0')
  return d.getUTCFullYear() + '-' + p(d.getUTCMonth() + 1) + '-' + p(d.getUTCDate()) +
    ' ' + p(d.getUTCHours()) + ':' + p(d.getUTCMinutes())
}
function levelTag(lv) {
  const s = String(lv || '').toUpperCase()
  if (s === 'P0') return '<span class="tag p0">特急</span>'
  if (s === 'P1') return '<span class="tag p1">重要</span>'
  return '<span class="tag p2">一般</span>'
}
function pageHtml(items, title, tip) {
  const rows = items.map(it => (
    '<li class="row"><div class="meta">' + levelTag(it.level) +
      '<span class="time">' + esc(fmtBj(it.ts)) + '</span>' +
      '<span class="src">' + esc(it.sender || it.source || '') + '</span></div>' +
      '<div class="body">' + esc(it.title).replace(/\n/g, '<br>') + '</div>' +
      (it.ddl ? '<div class="ddl">截止 ' + esc(it.ddl) + '</div>' : '') + '</li>'
  )).join('')
  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + esc(title) + '</title><style>' +
    ':root{--bg:#f6f7f9;--card:#fff;--line:#e6e8eb;--txt:#1f2328;--sub:#6b7280;--p0:#c0392b;--p1:#d68910;--p2:#5b8def}' +
    'body{margin:0;background:var(--bg);color:var(--txt);font:15px/1.6 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}' +
    '.head{position:sticky;top:0;background:rgba(246,247,249,.92);backdrop-filter:blur(6px);padding:14px 16px 10px;border-bottom:1px solid var(--line)}' +
    '.head h1{margin:0;font-size:17px;font-weight:600}.head p{margin:4px 0 0;font-size:12px;color:var(--sub)}' +
    'ul{list-style:none;margin:0;padding:10px 12px 40px}' +
    '.row{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:11px 13px;margin-bottom:9px}' +
    '.meta{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--sub);margin-bottom:5px;flex-wrap:wrap}' +
    '.time{margin-left:auto}.tag{border-radius:4px;padding:1px 6px;font-size:11px;color:#fff;background:var(--p2)}' +
    '.p0{background:var(--p0)} .p1{background:var(--p1)}.body{white-space:pre-wrap;word-break:break-word}' +
    '.ddl{margin-top:5px;font-size:12px;color:var(--p0)}.empty{color:var(--sub);text-align:center;padding:30px 0}' +
    '</style></head><body><div class="head"><h1>' + esc(title) + '</h1><p>' + esc(tip) + '</p></div><ul>' +
    (rows || '<li class="empty">还没有内容 —— ' + esc(tip) + '</li>') + '</ul></body></html>'
}


/* ==================== 提纯：只留「有信息量」的消息（跟本机 pull_qq.py 同一套规则） ==================== */
const KEEP_PATTERNS = [
  /(截止|截至|deadline|ddl|前交|前发|交材料|提交|报名)/, /(考试|测验|补考|重修|成绩|绩点|学分)/,
  /(讲座|培训|会议|开会|活动|比赛|竞赛|答辩| seminar| workshop)/i, /(放假|调休|上课|停课|补课|校历|作息|早八)/,
  /(通知|公告|提醒|请注意|务必|一定要|别忘|记得)/, /(附件|文件|资料|链接|二维码|见附件)/,
  /(报名|招募|志愿者|班委|团委|学生会|社团)/,
]
const DROP_RE = /^(哈+|呵+|嗯+|哦+|啊+|草|6|666|顶|沙发|签到|打卡|早|晚安|午安|收到|好的?|OK|ok|谢谢|thx|谢了|图|表情)$/i

function isMerit(t) {
  if (!t || t.length < 4) return null
  const s = t.trim()
  if (DROP_RE.test(s)) return null
  for (const re of KEEP_PATTERNS) if (re.test(s)) return 'info'
  return null
}

/* 🔴 2026-10-07 主公改的规则：**不再靠关键词自动筛**。
   原来用 isMerit() 只放行含「通知/截止/报名」等词的消息，结果把
   「看着像闲聊、其实是通知」的也一并丢了 —— 群里明明发了消息，页面空空如也。
   改成：**全收，由班长在页面里勾选删掉杂乱的**。这里只挡「完全没内容」那种：
     · 空白 / 单字 / 纯表情 / 纯寒暄（DROP_RE）
   其余一律放行 —— 宁可多收让人删，也不要漏掉正经通知。 */
function shouldKeep(t) {
  if (!t) return false
  const s = String(t).trim()
  if (s.length < 2) return false
  if (DROP_RE.test(s)) return false
  return true
}
function digestText(t) {
  let s = String(t)
  s = s.replace(/@[\w\u4e00-\u9fa5]{1,12}\s*/g, '')
  s = s.replace(/(?:[哈呵嗯哦啊]{2,}|[!！?？。]{2,})/g, ' ')
  s = s.replace(/(收到|好的?|谢谢|麻烦了|辛苦了|各位|同学们|同学们好)+/g, ' ')
  /* 🔴 姓名脱敏（2026-10-04 补）。
     此前 scrub() 只洗身份证/手机/学号，姓名原样进摘要，出现过「岗位：姓名、姓名」这类
     点名排班被直接推到公开仓库，而 note 里却写着「已脱敏：不含姓名」——自述与事实不符。

     就一条规则：点名列表「标签：姓名、姓名…」→「标签：（名单已隐去）」。
     刻意**不做**「XX老师 → 老师」：实测 `{2,3}` 贪婪会把「由王老师」吃成「老师主讲」，
     而前面是标点的单姓（「，张老师」）只匹配到 1 字又漏洗，两头不讨好；
     且「某老师」本身不构成具名泄露。零误伤优先于多洗一个。 */
  s = s.replace(/([：:])\s*[\u4e00-\u9fa5]{2,3}(?:、[\u4e00-\u9fa5]{2,3})+/g, '$1（名单已隐去）')
  s = s.replace(/\s{2,}/g, ' ').trim().replace(/^[-—·:：\s]+|[-—·:：\s]+$/g, '')
  if (s.length > 120) s = s.slice(0, 120) + '…'
  return s
}


/* ==================== 云端直接写 GitHub（0 元持久化，关键！）
   为什么：云函数内存必丢，但 **GitHub 仓库是持久的**，
   而且同学看的就是 GitHub Pages —— 云端直接写进去，等于「云端就是数据库」。
   电脑关着也不丢（云端 24h 在岗），且 GitHub 本身 0 元。
   需要环境变量：GH_TOKEN / GH_REPO / GH_BRANCH / GH_PATH（都在控制台配，不进代码）。 */
const GH_API = 'https://api.github.com'

/* repo 参数：(2026-10-07) 班群摘要必须写进**私密库**，而 access.json 仍留公开站。
   两件事共用一个 GH_REPO 会互相拖累，所以给班群摘要单开 GH_REPO_QQ / GH_PATH_QQ。
   不传 repo 时回落 GH_REPO，老调用点（adminApi 写 access.json）行为完全不变。 */
async function ghGetFile(path, token, repo) {
  const url = GH_API + '/repos/' + (repo || process.env.GH_REPO) + '/contents/' + path
  const r = await httpJson('GET', url, {
    'User-Agent': 'shezhang-bot', 'Accept': 'application/vnd.github+json',
    'Authorization': 'token ' + token,
  }, null, 20000)
  if (r.status !== 200) return null
  try {
    const j = JSON.parse(r.body)
    return { sha: j.sha, content: Buffer.from(j.content || '', 'base64').toString('utf8') }
  } catch (e) { return null }
}

/* rawB64：content 已是 base64 字符串时传 true（用于后台「上传资料」传二进制文件）。
   Buffer.from(x,'utf8') 会把任意字节当成 UTF-8 解码，二进制一进来就变 U+FFFD，
   推上去的文件会坏 —— 所以这条口子必须显式开，别默认走老路径。 */
async function ghPutFile(path, token, content, sha, message, repo, rawB64) {
  const url = GH_API + '/repos/' + (repo || process.env.GH_REPO) + '/contents/' + path
  const payload = JSON.stringify({
    message: message || 'chore: 群消息摘要自动更新',
    content: rawB64 ? String(content) : Buffer.from(content, 'utf8').toString('base64'),
    branch: process.env.GH_BRANCH || 'main',
    ...(sha ? { sha } : {}),
  })
  const r = await httpJson('PUT', url, {
    'User-Agent': 'shezhang-bot', 'Accept': 'application/vnd.github+json',
    'Authorization': 'token ' + token, 'Content-Type': 'application/json',
  }, payload, 25000)
  return { status: r.status, body: String(r.body).slice(0, 300) }
}

/* 班群摘要的落点。2026-10-07 起默认写**私密库**：
   ① GH_REPO_QQ / GH_PATH_QQ 优先（指向 bicheng2026/daily-plan，Private）；
   ② 未配置时才回落 GH_REPO / GH_PATH（老部署行为）。

   为什么要改：原先 GH_REPO 指向公开站 shezhang2，于是云函数每收一条群消息
   就往公开仓库写一次班群内容，而 .github/workflows/sync-todo.yml 里的
   「隐私红线自检」每 30 分钟又把它删掉 —— 两边拉锯，既违反主公 09-30
   立下的红线（群聊内容只落本机、绝不进公开仓库），功能也稳定不了。
   分开配置后：班群摘要进私密库，access.json 仍写公开站，互不干扰。 */
function qqPath() {
  return process.env.GH_PATH_QQ || process.env.GH_PATH || 'data/qq_digest.json'
}

/* ==================== 班群口令（2026-10-07 新增）====================
   需求：管理员后台要能「显示」和「重置」班群口令。
   约束：云函数改不了自己的环境变量（那是控制台的事），所以口令必须落到**文件**；
        而明文口令绝不能进公开仓库，于是存**私密库**（同 GH_REPO_QQ）。
   取值顺序：私密库文件 → 环境变量 READ_TOKEN（老部署无文件时行为不变）。 */
function qqTokenPath() {
  return process.env.GH_PATH_QQ_TOKEN || 'shezhang_qq_token.json'
}
async function getQqToken() {
  const fallback = process.env.READ_TOKEN || ''
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return fallback
  try {
    const cur = await ghGetFile(qqTokenPath(), token, repo)
    if (!cur) return fallback
    const j = JSON.parse(cur.content)
    return (j && j.token) ? String(j.token) : fallback
  } catch (e) {
    console.log('[shezhang] 读班群口令失败，回落环境变量：' + String((e && e.message) || e))
    return fallback
  }
}
async function setQqToken(t) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return { ok: false, msg: '没配 GH_TOKEN / GH_REPO_QQ' }
  try {
    const cur = await ghGetFile(qqTokenPath(), token, repo)
    const body = JSON.stringify({
      note: '班群口令。存私密库（不公开），由管理员后台重置；同学在网页「待办 → 班群摘要」里用它打开云端页。',
      token: String(t),
      updated: Date.now(),
    }, null, 2)
    const r = await ghPutFile(qqTokenPath(), token, body, cur && cur.sha, 'chore: 更新班群口令', repo)
    return { ok: r.status === 200 || r.status === 201, gh: r }
  } catch (e) {
    return { ok: false, msg: String((e && e.message) || e) }
  }
}
/* ==================== 群消息入口的鉴权（2026-10-08 改为「业主令牌优先」）====================
   三条路都认，按优先级：
     ① **业主令牌**（szk_…）：认出来就只回**该 appid 自己**的消息 —— 这就是主公要的隔离；
     ② 管理员口令：老后台还在用，认（看全部，等同站长视角）；
     ③ 老班群口令：向后兼容，认（老部署没重配时行为不变）。
   ⚠️ 校验顺序不能反：先认令牌，才能把「谁在问」带出去用于过滤。 */
async function whoByAuth(given) {
  const t = String(given || '')
  if (!t) return null
  const owner = await whoByToken(t)
  if (owner) return { role: 'owner', appid: owner.appid }
  if (t === (process.env.ADMIN_TOKEN || '')) return { role: 'admin', appid: '' }
  if (t === (await getQqToken())) return { role: 'legacy', appid: '' }
  return null
}
/* 老的布尔口，保留给 /dbg 之类只判「能不能进」的地方 */
async function qqAuthOk(given) {
  return !!(await whoByAuth(given))
}

/* ==================== 机器人凭据（2026-10-08 重写成「凭据即身份」）====================
   主公的要求（原文）：
     「我要的是你写好逻辑，然后如果用户配置好了云函数，不需要到管理员接口再接，
       直接页面复制机器人那两要素也能接，任何用户都是拿到对应的机器人才能用，
       而不是现在用口令锁住」

   旧版错在哪：botget / botset 挂在 adminApi 底下，要先过管理员口令；
   班群消息又要班群口令；进站又要全网口令 —— 三重口令叠一起，正是主公反对的。

   新版模型（一句话：谁的机器人，谁的通道）：
     · **AppID + AppSecret 就是身份**，不需要任何第三方口令；
     · 用户一填，云函数现场验一次（拿 AppID/AppSecret 去 QQ 官方接口换 access_token，
       换得到 = 凭据是真的），验过就发一枚 `szk_` 开头的**接入令牌**；
     · 之后该用户的一切（群消息、上传、回调地址）都挂在 **appid 命名空间**下，
       A 班的令牌读不到 B 班的任何数据 —— 天然隔离，这正是主公要的「拿到对应的机器人才能用」。

   存储（都在**私密库**，明文凭据绝不进公开仓库）：
     shezhang_bots.json    { bots: { "<appid>": { secret, pubkey, token, school, note, ... } } }
     shezhang_qq_<appid>.json   该机器人的班群摘要
   ⚠️ 有一条网页替不了：QQ 开放平台的「回调地址」必须到 q.qq.com 后台填，
       本函数负责把该填的地址算出来给用户复制。 */
function botsPath() {
  return process.env.GH_PATH_BOTS || 'shezhang_bots.json'
}
/* 兼容老部署：单个 shezhang_bot.json 也认，读不到环境变量时才回落 */
function legacyBotPath() {
  return process.env.GH_PATH_BOT || 'shezhang_bot.json'
}

function botRec(appid) {
  const M = _botMem.get('map')
  return (M && M.bots && M.bots[String(appid)]) || null
}
function genBotToken() {
  return 'szk_' + _nc.randomBytes(18).toString('hex')
}
function maskSecret(s) {
  s = String(s || '')
  if (!s) return ''
  if (s.length <= 8) return '••••'
  return s.slice(0, 3) + '••••' + s.slice(-3)
}
/* 机器人摘要落点：每个 appid 一个文件，互不干扰 */
function qqPathOf(appid) {
  if (!appid) return qqPath()
  return String(process.env.GH_PATH_QQ_DIR || 'sz2-qq') + '/' + String(appid).replace(/[^\w-]/g, '') + '.json'
}

/* 一次性把「全部机器人」读进来（一个小文件，改动不频繁，云函数实例里缓存 60 秒） */
const _botMem = new Map()
const BOT_TTL = 60000
async function loadBots(force) {
  const now = Date.now()
  const hit = _botMem.get('map')
  if (!force && hit && (now - Number(_botMem.get('at') || 0)) < BOT_TTL) return hit
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  let map = { note: '各班机器人凭据（私密库，不公开）。键=AppID。', bots: {} }
  if (token && repo) {
    try {
      const cur = await ghGetFile(botsPath(), token, repo)
      if (cur) {
        const j = JSON.parse(cur.content)
        if (j && j.bots && typeof j.bots === 'object') map = j
      }
    } catch (e) {
      console.log('[shezhang] 读机器人表失败：' + String((e && e.message) || e))
    }
  }
  /* 环境变量兜底：老部署只有一个机器人，且没写进表 —— 补一条进去（内存态，不写盘） */
  const envApp = process.env.BOT_APPID || ''
  if (envApp && !map.bots[envApp] && process.env.BOT_SECRET) {
    map.bots[envApp] = {
      secret: process.env.BOT_SECRET,
      pubkey: process.env.PUBKEY || '',
      token: process.env.BOT_ACCESS_TOKEN || '',
      from: 'env',
    }
  }
  _botMem.set('map', map)
  _botMem.set('at', now)
  return map
}
async function saveBots(map) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return { ok: false, msg: '没配 GH_TOKEN / GH_REPO_QQ' }
  try {
    const cur = await ghGetFile(botsPath(), token, repo)
    const r = await ghPutFile(botsPath(), token, JSON.stringify(map, null, 2),
      cur && cur.sha, 'chore: 更新机器人接入表', repo)
    if (r.status === 200 || r.status === 201) {
      _botMem.set('map', map); _botMem.set('at', Date.now())
      return { ok: true, gh: r }
    }
    return { ok: false, msg: 'GitHub 拒绝（HTTP ' + r.status + '）', gh: r }
  } catch (e) {
    return { ok: false, msg: String((e && e.message) || e) }
  }
}

/* ---- 旧接口兼容：getBotCfg / setBotCfg（后台那套还在用，不破坏老逻辑）----
   现在语义变成「主机器人」= 环境变量 BOT_APPID 指的那个；没配就取表里第一个。 */
async function getBotCfg() {
  const fallback = {
    appid: process.env.BOT_APPID || '',
    secret: process.env.BOT_SECRET || '',
    pubkey: process.env.PUBKEY || '',
  }
  try {
    const map = await loadBots()
    const ids = Object.keys(map.bots || {})
    const want = fallback.appid || ids[0]
    const b = want ? map.bots[want] : null
    if (b) {
      return {
        appid: want,
        secret: b.secret || fallback.secret,
        pubkey: b.pubkey || fallback.pubkey,
        token: b.token || '',
      }
    }
  } catch (e) {
    console.log('[shezhang] getBotCfg 回落环境变量：' + String((e && e.message) || e))
  }
  return fallback
}
/* 写入主机器人（老后台用）。patch 里带 appid 就写那个，否则写环境变量指的那个。 */
async function setBotCfg(patch) {
  const map = await loadBots(true)
  const appid = String((patch && patch.appid) || process.env.BOT_APPID || '').trim()
  if (!appid) return { ok: false, msg: '没给 appid，环境变量里也没有 BOT_APPID' }
  const cur = map.bots[appid] || {}
  map.bots[appid] = Object.assign({}, cur, {
    secret: patch.secret || cur.secret || '',
    pubkey: patch.pubkey || cur.pubkey || '',
    token: cur.token || '',
    from: 'admin',
    updated: Date.now(),
  })
  if (!map.bots[appid].token) map.bots[appid].token = genBotToken()
  return await saveBots(map)
}

/* ---- 出网：拿 AppID + AppSecret 去 QQ 官方换 access_token（验凭据真伪）----
   QQ 开放平台 2024+ 的接口：
     POST https://bots.qq.com/app/getAppAccessToken
     body { appId, clientSecret }  →  { access_token, expires_in }
   换得到 = 这对凭据是真的、且 appid 是本人的。
   ⚠️ 这个接口在网络受限时可能连不上，所以**失败不阻断接入**：
      仍发令牌，但标 verified=false，页面上提示「未能联网核验，请自行确认凭据无误」。 */
async function verifyQqCredential(appid, secret) {
  try {
    const r = await httpJson('POST', 'https://bots.qq.com/app/getAppAccessToken',
      { 'Content-Type': 'application/json', 'User-Agent': 'shezhang-bot' },
      JSON.stringify({ appId: String(appid), clientSecret: String(secret) }), 12000)
    if (r.status !== 200) return { ok: false, why: 'HTTP ' + r.status, body: String(r.body).slice(0, 200) }
    const j = JSON.parse(r.body)
    if (j && j.access_token) return { ok: true, expires: Number(j.expires_in) || 0 }
    return { ok: false, why: (j && (j.message || j.msg || j.code)) || '返回里没有 access_token' }
  } catch (e) {
    return { ok: false, why: String((e && e.message) || e) }
  }
}

/* 接入令牌 → 机器人记录（所有「按 appid 隔离」的入口都先过这一关） */
async function whoByToken(given) {
  const t = String(given || '').trim()
  if (!t.startsWith('szk_')) return null
  const map = await loadBots()
  for (const id of Object.keys(map.bots || {})) {
    if (map.bots[id] && map.bots[id].token === t) return { appid: id, rec: map.bots[id] }
  }
  return null
}

/* 把一条群消息提纯后写进 GitHub 的摘要文件（每次覆盖，保留最近 30 条）
   2026-10-08：落点按 appid 分文件（qqPathOf），每个班自己一份，互不串门。 */
async function publishToGithub(item, appid) {
  const token = process.env.GH_TOKEN
  const path = qqPathOf(appid)
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return { skipped: '没配 GH_TOKEN / GH_REPO_QQ' }

  const cur = await ghGetFile(path, token, repo)
  let obj = { note: '本内容由班委助手自动整理自班群消息（已脱敏：不含姓名/学号/手机号，仅保留有信息量的通知类内容）。如需原文请在班群内翻记录。', count: 0, items: [] }
  if (cur) {
    try { obj = JSON.parse(cur.content) } catch (e) { }
  }
  const text = digestText(item.title)
  // 幂等：同 id 不重复加
  const items = (obj.items || []).filter(x => x.id !== item.id)
  items.unshift({
    id: item.id,
    time: new Date(item.ts).toISOString(),
    timeText: fmtBj(item.ts).slice(5),
    text: text,
  })
  obj.items = items.slice(0, 30)
  obj.count = obj.items.length
  obj.appid = String(appid || '')
  obj.updated = item.ts
  obj.updated_text = fmtBj(item.ts)
  const r = await ghPutFile(path, token, JSON.stringify(obj, null, 2), cur && cur.sha,
    'chore: 班群摘要 +' + String(item.id).slice(-8), repo)
  return r
}

/* 从摘要里删掉若干条（2026-10-07 新增：页面勾选后手动清理）
   2026-10-08：也按 appid 走，谁也不能删别人的。 */
async function qqRemoveItems(killSet, appid) {
  const token = process.env.GH_TOKEN
  const path = qqPathOf(appid)
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return { removed: 0, left: 0, err: '没配 GH_TOKEN / GH_REPO_QQ' }
  const cur = await ghGetFile(path, token, repo)
  if (!cur) return { removed: 0, left: 0, err: '摘要文件不存在' }
  let obj
  try { obj = JSON.parse(cur.content) } catch (e) { return { removed: 0, left: 0, err: '摘要文件损坏' } }
  const before = (obj.items || []).length
  obj.items = (obj.items || []).filter(x => !killSet.has(String(x.id)))
  obj.count = obj.items.length
  const r = await ghPutFile(path, token, JSON.stringify(obj, null, 2), cur.sha,
    'chore: 清理 ' + (before - obj.items.length) + ' 条群消息', repo)
  return { removed: before - obj.items.length, left: obj.items.length, status: r.status }
}

/* ==================== 黑匣子 ==================== */
async function record(entry) {
  try {
    let arr = []
    const raw = await KV().get('dbg')
    if (raw) { const a = JSON.parse(raw); if (Array.isArray(a)) arr = a }
    arr.unshift(entry)
    await KV().put('dbg', JSON.stringify(arr.slice(0, 10)))
  } catch (e) { }
}

/* ==================== 工具 ==================== */
function parseQuery(qs) {
  const out = {}
  const s = String(qs || '').replace(/^\?/, '')
  if (!s) return out
  for (const kv of s.split('&')) {
    if (!kv) continue
    const i = kv.indexOf('=')
    const k = i < 0 ? kv : kv.slice(0, i)
    const v = i < 0 ? '' : kv.slice(i + 1)
    try { out[decodeURIComponent(k)] = decodeURIComponent(v) } catch (e) { out[k] = v }
  }
  return out
}
function headerOf(headers, name) {
  for (const k in headers) {
    if (String(k).toLowerCase() === name) {
      const v = headers[k]
      return Array.isArray(v) ? v.join(',') : (v || '')
    }
  }
  return ''
}

/* ==================== 业务：QQ 回调 ==================== */
async function handleQQ(event, body, qs) {
  let payload = null
  if (body) { try { payload = JSON.parse(body) } catch (e) { payload = null } }

  const headers = event.headers || {}
  /* 2026-10-08：先认「这条回调是谁家的机器人」——
     QQ 每个机器人的回调地址不同（路径里带 appid，见 /bot 返回的回调地址），
     所以优先看 URL 上的 ?bot=<appid>，其次看 X-Bot-AppId 头，最后回落主机器人。 */
  const map = await loadBots()
  const ids = Object.keys(map.bots || {})
  let appid = String(qs.bot || '').trim()
  if (!appid) appid = headerOf(headers, 'x-bot-appid')
  if (!appid) appid = String(process.env.BOT_APPID || ids[0] || '')

  await record({
    at: Date.now(),
    method: event.httpMethod,
    path: event.path,
    ua: headerOf(headers, 'user-agent'),
    appid: appid || headerOf(headers, 'x-bot-appid'),
    query: event.queryString || '',
    body: String(body || '').slice(0, 600),
  })

  // 回调验证：回 {plain_token, signature}
  // ⚠️ 查不到时是 null 不是 undefined（不是 undefined），判空必须用 != null
  let pt = findKey(payload, 'plain_token', 5)
  let ets = findKey(payload, 'event_ts', 5)
  if (pt === undefined || pt === null) pt = qs.plain_token
  if (ets === undefined || ets === null) ets = qs.event_ts
  if (pt !== undefined && pt !== null && ets !== undefined && ets !== null) {
    let sig = ''
    /* 2026-10-08：验签必须用**这个机器人自己的** secret（多机器人共存时不能张冠李戴） */
    try { sig = await signHex(String(ets) + String(pt), appid) } catch (e) { sig = 'ERR:' + String((e && e.message) || e) }
    console.log('[shezhang] 回调验证 appid=' + appid + ' pt=' + String(pt).slice(0, 8) + ' sig=' + (sig || '').slice(0, 16))
    return { plain_token: String(pt), signature: sig }
  }

  if (!payload) return { _status: 400, code: 400, msg: 'body 不是合法 JSON' }

  const ev = parseEvent(payload)
  if (!ev) return { code: 0, msg: '非消息事件，忽略' }

  const watch = String(process.env.WATCH_GROUPS || '').split(',').map(s => s.trim()).filter(Boolean)
  if (watch.length && watch.every(w => ev.gid.indexOf(w) < 0)) {
    return { code: 0, msg: '不在关注列表', gid: ev.gid }
  }

  const title = scrub(ev.text)
  if (!title) return { code: 0, msg: '脱敏后为空，丢弃' }

  const sigHeader = headerOf(headers, 'x-signature') || headerOf(headers, 'signature')
  const myPub = (appid && botRec(appid) && botRec(appid).pubkey) || process.env.PUBKEY
  if (myPub && sigHeader) {
    const ok = await verifyHex(sigHeader.trim(), String(ev.ts) + body, appid)
    if (!ok) return { _status: 403, code: 403, msg: '验签不过' }
  }

  const item = {
    id: 'qq_' + ev.mid,
    source: 'qq',
    sender: ev.gid ? 'QQ群 ' + ev.gid.slice(0, 10) : 'QQ群',
    title: title.slice(0, 200),
    ts: ev.ts,
    appid: appid,
    level: 'P2', ddl: '', status: 'open',
  }
  await kvPut('qq', item.id, item)
  await bumpIndex('qq', item)

  // 0 元持久化：云端直接写 GitHub（同学看的就是 Pages，等于云端即数据库）
  let gh = null
  if (process.env.GH_TOKEN && process.env.GH_REPO) {
    /* 改成「全收」：不再用关键词规则筛，交给班长在页面里勾选删除 */
    if (shouldKeep(title)) {
      try { gh = await publishToGithub(item, appid) } catch (e) { gh = { err: String((e && e.message) || e) } }
    } else {
      gh = { skipped: '空白/纯寒暄，不进摘要' }
    }
  }
  return { code: 0, msg: '已入库', id: item.id, appid: appid, gh: gh || undefined }
}

/* ==================== 业务：公告推送 ==================== */
async function handleSync(event, body) {
  const admin = process.env.ADMIN_TOKEN || ''
  if (!admin) return { _status: 500, code: 500, msg: '服务端没配 ADMIN_TOKEN' }
  if (headerOf(event.headers || {}, 'authorization') !== 'Bearer ' + admin) {
    return { _status: 401, code: 401, msg: 'token 不对' }
  }
  let payload
  try { payload = JSON.parse(body) } catch (e) { return { _status: 400, code: 400, msg: 'body 不是合法 JSON' } }
  const items = Array.isArray(payload.items) ? payload.items : []
  let ok = 0
  for (const it of items) {
    if (!it || !it.id) continue
    it.title = String(it.title || '').slice(0, 200)
    if (!it.ts) it.ts = Date.now()
    await kvPut('ann', it.id, it)
    await bumpIndex('ann', it)
    ok++
  }
  return { code: 0, msg: '同步完成', count: ok }
}

/* ==================== 运行时探测（排错用） ==================== */
async function probeRuntime() {
  const out = { node: process.version, globalCrypto: false, webcrypto: false, algos: {}, nodeEd25519: '' }
  out.globalCrypto = !!(typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle)
  const wc = _nc.webcrypto && _nc.webcrypto.subtle
  out.webcrypto = !!wc
  if (wc) {
    for (const name of ['Ed25519', 'Ed448', 'X25519']) {
      try { await wc.importKey('raw', new Uint8Array(32), { name }, false, ['sign']); out.algos[name] = 'OK' }
      catch (e) { out.algos[name] = String((e && e.name) || e).slice(0, 50) }
    }
  }
  try {
    const kp = _nc.generateKeyPairSync('ed25519')
    out.nodeEd25519 = 'OK siglen=' + _nc.sign(null, Buffer.from('x'), kp.privateKey).length
  } catch (e) { out.nodeEd25519 = String((e && e.message) || e).slice(0, 80) }
  return out
}


/* ---------------- 出网探测 + 主动写 GitHub
   ⚠️ Node 16 没有全局 fetch（要 Node 18+），用 https 模块。
   如果这条通了，就能在**云端直接推 GitHub** → 电脑关着也不丢，且 0 元。 */
const _https = require('https')
const _http = require('http')

function httpGet(urlStr, headers, timeoutMs) {
  return new Promise((resolve) => {
    try {
      const u = new URL(urlStr)
      const lib = u.protocol === 'http:' ? _http : _https
      const req = lib.request(
        { hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
          path: u.pathname + u.search, method: 'GET',
          headers: headers || {}, timeout: timeoutMs || 20000 },
        (res) => {
          let body = ''
          res.on('data', (d) => { body += d.toString() })
          res.on('end', () => resolve({ status: res.statusCode, body }))
        })
      req.on('error', (e) => resolve({ status: 0, body: 'ERR ' + String(e && e.message || e) }))
      req.on('timeout', () => { req.destroy(); resolve({ status: 0, body: 'TIMEOUT' }) })
      req.end()
    } catch (e) {
      resolve({ status: 0, body: 'ERR ' + String(e && e.message || e) })
    }
  })
}

function httpJson(method, urlStr, headers, payload, timeoutMs) {
  return new Promise((resolve) => {
    try {
      const u = new URL(urlStr)
      const lib = u.protocol === 'http:' ? _http : _https
      const data = payload == null ? null : Buffer.from(payload, 'utf8')
      const hd = Object.assign({}, headers || {})
      if (data) hd['Content-Length'] = data.length
      const req = lib.request(
        { hostname: u.hostname, port: u.port || (u.protocol === 'http:' ? 80 : 443),
          path: u.pathname + u.search, method, headers: hd, timeout: timeoutMs || 20000 },
        (res) => {
          let body = ''
          res.on('data', (d) => { body += d.toString() })
          res.on('end', () => resolve({ status: res.statusCode, body }))
        })
      req.on('error', (e) => resolve({ status: 0, body: 'ERR ' + String(e && e.message || e) }))
      req.on('timeout', () => { req.destroy(); resolve({ status: 0, body: 'TIMEOUT' }) })
      if (data) req.write(data)
      req.end()
    } catch (e) {
      resolve({ status: 0, body: 'ERR ' + String(e && e.message || e) })
    }
  })
}

async function probeOutbound() {
  const out = {}
  const g = await httpGet('https://api.github.com/rate_limit', {
    'User-Agent': 'shezhang-probe',
  })
  out.github = g.status
  out.github_body = String(g.body).slice(0, 120)
  const q = await httpGet('https://www.qq.com/', { 'User-Agent': 'probe' })
  out.qq = q.status
  return out
}


/* ==================== 后台上传资料（2026-10-08 改为真能传）====================
   背景：后台「上传资料到文库」原来只回一句「请让毕成代劳」—— 按键是假的。
   真解：云函数手上就有 GH_TOKEN，前端把文件 base64 发过来，云函数代写仓库，
        token 依旧不经过浏览器。鉴权沿用管理员口令（sha256(salt::pw)）。
   三条硬约束（都是线上实测的，别想当然改）：
     1) SCF 函数 URL 的 body 上限 6MB → 单文件 2.5MB 封顶（base64 膨胀后约 3.4MB）；
     2) 只准写 lib/00_待入库/ 这一个前缀 —— 挡住 ../ 穿越和乱写仓库；
     3) 前端一次只能串行传一个（并发 PUT 同一路径会 409）。 */
const UP_DIR = 'lib/00_待入库'
const UP_MAX = 2.5 * 1024 * 1024

function safeName(n) {
  const s = String(n == null ? '' : n)
    .replace(/[\\/]+/g, '_')          // 路径分隔符 → 下划线（挡路径穿越）
    .replace(/[\x00-\x1f\x7f]+/g, '_') // 控制字符
    .replace(/[:<>?"|*]+/g, '_')      // Windows 非法字符
    .replace(/^\.+/, '')              // 开头的点（挡 . / ..）
    .replace(/\s+$/g, '')
    .slice(0, 120)
  return s || 'unnamed'
}

async function upPut(name, b64) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO
  if (!token || !repo) return { ok: false, msg: '服务端没配 GH_TOKEN/GH_REPO' }
  const fn = safeName(name)
  const dest = UP_DIR + '/' + fn
  const cur = await ghGetFile(dest, token, repo)
  /* rawB64=true：内容已经是 base64 字符串，绝不能再走 Buffer.from(x,'utf8')，
     否则二进制文件推上去会变成一堆 U+FFFD（蛇杖二号踩过同一个坑）。 */
  const r = await ghPutFile(dest, token, b64, cur && cur.sha,
    'feat: 后台上传资料 ' + fn, repo, true)
  if (r.status !== 200 && r.status !== 201) {
    return { ok: false, msg: 'GitHub 拒绝（HTTP ' + r.status + '）', gh: r }
  }
  return { ok: true, path: dest, bytes: Math.round(String(b64).length * 0.75), name: fn }
}

async function upList() {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO
  if (!token || !repo) return { ok: false, msg: '服务端没配 GH_TOKEN/GH_REPO' }
  const r = await httpJson('GET', GH_API + '/repos/' + repo + '/contents/' + UP_DIR, {
    'User-Agent': 'shezhang-bot', 'Accept': 'application/vnd.github+json',
    'Authorization': 'token ' + token,
  }, null, 20000)
  if (r.status !== 200) return { ok: false, msg: '读目录失败（HTTP ' + r.status + '）' }
  let arr = null
  try { arr = JSON.parse(r.body) } catch (e) { return { ok: false, msg: '目录返回异常' } }
  const files = (Array.isArray(arr) ? arr : [])
    .filter(x => x && x.type === 'file')
    .map(x => ({ name: String(x.name), size: Number(x.size) || 0 }))
    .sort((a, b) => b.size - a.size)
  return { ok: true, count: files.length, files: files.slice(0, 100) }
}

/* ==================== 机器人接入接口（2026-10-08 新增，**不走管理员口令**）====================
   这就是主公要的那个东西：用户在页面上贴「机器人两要素」，当场接上，不需要任何后台口令。

   动作（全部 POST /bot?action=…，body 里带参数）：
     claim  { appid, secret, pubkey?, school? }
            —— 唯一的「接入」动作。验一次凭据 → 记表 → 发令牌。
            ★ 这就是「复制机器人两要素也能接」：贴上去即通。
     who    { token }   —— 用令牌问「我是谁 / 我接的是哪个机器人」（页面刷新时用）
     info   { token }   —— 我的回调用地址 + 群消息统计（页面显示用）
     revoke { token }   —— 换发一枚新令牌（旧令牌立即失效，等同「退出登录」）

   🔴 安全边界（想清楚再改）：
     · **令牌是唯一凭据**，页面只存令牌（localStorage），secret 从不回传页面；
     · 令牌绑在 appid 上，A 的令牌读不到 B 的任何数据；
     · claim 是「凭 secret 领令牌」——**能拿到 secret 的本来就是机器人主人**，
       所以这里不需要额外加口令（这正是主公说的「拿到对应的机器人才能用」）。 */
async function botApi(action, bodyObj) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO_QQ || process.env.GH_REPO
  if (!token || !repo) return { _status: 500, code: 500, msg: '服务端没配 GH_TOKEN / GH_REPO_QQ' }

  const callbackOf = (appid) => String(process.env.PUBLIC_BASE || '') + '/qq?bot=' + encodeURIComponent(appid)

  if (action === 'claim') {
    const appid = String((bodyObj && bodyObj.appid) || '').trim()
    const secret = String((bodyObj && bodyObj.secret) || '').trim()
    const pubkey = String((bodyObj && bodyObj.pubkey) || '').trim()
    const school = String((bodyObj && bodyObj.school) || '').trim()
    if (!appid || !secret) return { _status: 400, code: 400, msg: 'AppID 和 AppSecret 都要填' }
    if (!/^\d{5,20}$/.test(appid)) return { _status: 400, code: 400, msg: 'AppID 应该是一串数字（例如 1905465027）' }
    if (secret.length < 16) return { _status: 400, code: 400, msg: 'AppSecret 看着太短，是不是复制漏了' }

    /* 🔴 2026-10-11 新增加入白名单闸门（主公要求：我的函数只服务我的机器人）。
       背景：上一轮把地址做成可配置后，别人**偷懒不填自己的云函数**时，
             请求仍会落到站长这台 —— 数据虽是隔离的，但等于拿站长的函数给别人白打工。

       规则：
         · `BOT_ALLOW_APPIDS` **没配** → 维持老行为（谁都能接，向后兼容，老部署不炸）；
         · 配了（逗号分隔的 AppID 列表） → **只认列表里的**，其余一律 403 并给出引导。
       为什么用「列表」而不是「单个 BOT_APPID」：站长自己以后想加第二个机器人，
       改一个环境变量加个逗号就行，不用改代码。 */
    const allow = String(process.env.BOT_ALLOW_APPIDS || '').split(',')
      .map(s => s.trim()).filter(Boolean)
    if (allow.length && allow.indexOf(appid) < 0) {
      return {
        _status: 403, code: 403, msg: '这台云函数不接收这个机器人',
        hint: '这不是你的云函数。请照「自助部署指南 → 三·B」部署一台自己的，' +
              '再在「设置 → 我的云函数」里填上你的地址。',
        isMine: false,
      }
    }

    /* 现场联网核验一次：换得到 QQ 的 access_token 说明这对凭据是真的。
       连不上官方接口时不阻断（标 verified=false），免得网络受限把人拦在外面。 */
    const v = await verifyQqCredential(appid, secret)

    const map = await loadBots(true)
    const cur = map.bots[appid] || {}
    /* 令牌：老令牌还在就**沿用**（换设备重填不用改别处）；没有才新发 */
    const keepToken = cur.token && cur.token.startsWith('szk_') ? cur.token : genBotToken()
    map.bots[appid] = Object.assign({}, cur, {
      secret: secret,
      pubkey: pubkey || cur.pubkey || '',
      school: school || cur.school || '',
      token: keepToken,
      verified: !!v.ok,
      verifyNote: v.ok ? ('已核验（access_token 有效期 ' + v.expires + 's）') : ('未联网核验：' + (v.why || '')),
      claimedAt: cur.claimedAt || Date.now(),
      updated: Date.now(),
    })
    const w = await saveBots(map)
    if (!w.ok) return { _status: 500, code: 500, msg: '保存失败：' + (w.msg || '') }
    return {
      action: 'claim', ok: true, appid: appid, token: keepToken,
      verified: !!v.ok, verifyNote: map.bots[appid].verifyNote,
      callback: callbackOf(appid),
      qqPath: qqPathOf(appid),
    }
  }

  /* 以下动作都要令牌 */
  const given = String((bodyObj && bodyObj.token) || '')
  const owner = await whoByToken(given)
  if (!owner) return { _status: 401, code: 401, msg: '令牌无效或已失效，请重新接入' }
  const appid = owner.appid
  const rec = owner.rec || {}

  if (action === 'who') {
    return { action: 'who', ok: true, appid: appid, school: rec.school || '',
             verified: !!rec.verified, claimedAt: rec.claimedAt || 0 }
  }
  if (action === 'info') {
    const items = await listItems('qq', 200, appid)
    return {
      action: 'info', ok: true, appid: appid, school: rec.school || '',
      callback: callbackOf(appid),
      hasSecret: !!rec.secret, hasPubkey: !!rec.pubkey,
      secretMask: maskSecret(rec.secret),
      verified: !!rec.verified, verifyNote: rec.verifyNote || '',
      qqCount: items.length,
      qqLatest: items.length ? (items[0].timeText || '') : '',
    }
  }
  if (action === 'revoke') {
    const map = await loadBots(true)
    if (!map.bots[appid]) return { _status: 404, code: 404, msg: '这个机器人还没接入' }
    map.bots[appid].token = genBotToken()
    map.bots[appid].updated = Date.now()
    const w = await saveBots(map)
    if (!w.ok) return { _status: 500, code: 500, msg: '换发失败：' + (w.msg || '') }
    return { action: 'revoke', ok: true, appid: appid, token: map.bots[appid].token }
  }
  return { _status: 400, code: 400, msg: '未知动作（claim / who / info / revoke）' }
}

/* ==================== 管理员接口（后台按钮的中间层）====================
   为什么必须有这一层：**GitHub token 不能放前端**（放了就人人可读，等于仓库敞开）。
   云函数已经握着 GH_TOKEN，所以让它代写 data/access.json —— 前端只发口令，不碰 token。
   鉴权：管理员密码哈希比对（跟网页同一个算法：SHA-256(salt::pw)）。
   动作：
     gen  —— 生成随机口令、24h 后失效、标记 temp=true（对方首次登录必须改密码）
     lock —— 立即作废（锁死）
     open —— 关闭密码锁（任何人可进）
     adminpw —— 改管理员密码 */
async function adminApi(action, bodyObj) {
  const token = process.env.GH_TOKEN
  const repo = process.env.GH_REPO
  if (!token || !repo) return { _status: 500, code: 500, msg: '服务端没配 GH_TOKEN/GH_REPO' }

  const path = process.env.GH_PATH || 'data/qq_digest.json'
  const accPath = 'data/access.json'
  const salt = (bodyObj && bodyObj.salt) || 'sz1'

  // 1) 读现有 access.json
  const cur = await ghGetFile(accPath, token)
  let acc = { lock: true, salt: salt, admin: '', user: '', temp: false, issuedAt: 0, until: 0 }
  if (cur) { try { acc = JSON.parse(cur.content) } catch (e) { } }

  // 2) 鉴权（改口令时用旧口令；其余动作也要管理员口令）
  const given = (bodyObj && bodyObj.pw) || ''
  if (!acc.admin) return { _status: 403, code: 403, msg: 'access.json 里没有 admin 哈希，先手工填一次' }
  const h = _nc.createHash('sha256').update(salt + '::' + given).digest('hex')
  if (h !== acc.admin) return { _status: 401, code: 401, msg: '管理员口令不对' }

  const now = Date.now()
  let msg = ''
  if (action === 'gen') {
    const gen = 'sz' + _nc.randomBytes(3).toString('hex') + '-' + _nc.randomBytes(2).toString('hex')
    const until = now + 24 * 3600 * 1000
    acc.user = _nc.createHash('sha256').update(salt + '::' + gen).digest('hex')
    acc.temp = true
    acc.issuedAt = now
    acc.until = until
    acc.lock = true
    msg = gen
  } else if (action === 'lock') {
    acc.lock = true; acc.user = ''; acc.temp = false; acc.until = 0
    msg = 'locked'
  } else if (action === 'open') {
    acc.lock = false; acc.temp = false; acc.until = 0
    msg = 'open'
  } else if (action === 'check') {
    /* 只校验口令，不改任何状态（后台打开时用它，别拿 gen 去校验——
       gen 会真的重置全网口令，等于「看一眼后台」就把门锁上了） */
    return { action: 'check', ok: true, until: acc.until || 0,
             acc_public: { lock: acc.lock, temp: acc.temp, until: acc.until } }
  } else if (action === 'adminpw') {
    const np = (bodyObj && bodyObj.newpw) || ''
    if (np.length < 6) return { _status: 400, code: 400, msg: '新管理员口令至少 6 位' }
    acc.admin = _nc.createHash('sha256').update(salt + '::' + np).digest('hex')
    msg = 'adminpw-updated'
  } else if (action === 'upload' || action === 'listup') {
    /* 后台「上传资料到文库」的真身（2026-10-08）。
       ⚠️ 这两个动作必须**提前 return**：adminApi 公共尾巴会把 acc 写回 access.json，
       上传一个文件却顺手 redo 一次口令配置 —— 多一次 commit 不说，
       万一当时 access.json 被别的流程改过还可能覆盖 sha 冲突。 */
    if (action === 'listup') {
      const l = await upList()
      if (!l.ok) return { _status: 500, code: 500, msg: l.msg }
      return { action: 'listup', ok: true, dir: UP_DIR, count: l.count, files: l.files }
    }
    const b64 = (bodyObj && bodyObj.b64) || ''
    const fn = (bodyObj && bodyObj.name) || ''
    if (!b64 || !fn) return { _status: 400, code: 400, msg: '缺 name / b64' }
    if (b64.length > Math.ceil((UP_MAX + 1024) / 3) * 4) {
      return { _status: 413, code: 413, msg: '文件太大（上限 2.5MB），大文件走桌面「上传资料.bat」' }
    }
    if (!/^[A-Za-z0-9+/=\s]+$/.test(b64)) {  // eslint-disable-line no-useless-escape
      return { _status: 400, code: 400, msg: 'b64 格式不对' }
    }
    const w = await upPut(fn, b64)
    if (!w.ok) return { _status: 500, code: 500, msg: w.msg, gh: w.gh }
    return { action: 'upload', ok: true, name: w.name, path: w.path, bytes: w.bytes }
  } else if (action === 'qqshow') {
    /* 班群口令：只读回显。它存在**私密库**，不在公开仓库，
       所以这里直接回明文给管理员是安全的（管理员口令已校验）。 */
    const tk = await getQqToken()
    return { action: 'qqshow', ok: true, token: tk || '',
             from: (tk && tk === (process.env.READ_TOKEN || '')) ? 'env' : 'file' }
  } else if (action === 'qqreset') {
    /* 重置：生成随机口令，写私密库。旧口令立即失效。 */
    const gen = 'qq' + _nc.randomBytes(4).toString('hex')
    const w = await setQqToken(gen)
    if (!w.ok) return { _status: 500, code: 500, msg: '写入班群口令失败：' + (w.msg || JSON.stringify(w.gh || {})) }
    return { action: 'qqreset', ok: true, token: gen, gh: w.gh }
  } else if (action === 'qqdel') {
    /* 页面勾选后删掉若干条。ids 传数组，也兼容单个 id。
       2026-10-08：带 appid 就删那个班的，不带就走主机器人（老行为）。 */
    const arr = Array.isArray(bodyObj && bodyObj.ids) ? bodyObj.ids : []
    const one = (bodyObj && bodyObj.id) || ''
    const kill = new Set(arr.concat(one ? [one] : []).map(String))
    if (!kill.size) return { _status: 400, code: 400, msg: '没给要删的 id' }
    const r = await qqRemoveItems(kill, String((bodyObj && bodyObj.appid) || ''))
    if (r.err) return { _status: 500, code: 500, msg: r.err }
    return { action: 'qqdel', ok: true, removed: r.removed, left: r.left }
  } else if (action === 'botlist') {
    /* 站长视角：这一台云函数下面接了几个机器人（只回公开字段，secret 不回） */
    const map = await loadBots(true)
    const list = Object.keys(map.bots || {}).map(id => ({
      appid: id,
      school: map.bots[id].school || '',
      verified: !!map.bots[id].verified,
      hasPubkey: !!map.bots[id].pubkey,
      secretMask: maskSecret(map.bots[id].secret),
      claimedAt: map.bots[id].claimedAt || 0,
      callback: String(process.env.PUBLIC_BASE || '') + '/qq?bot=' + id,
    }))
    return { action: 'botlist', ok: true, count: list.length, bots: list }
  } else if (action === 'botget') {
    /* 给网页后台读：appid 回明文，secret 只回「有没有」+ 掩码，不回完整值 */
    const c = await getBotCfg()
    const s = c.secret || ''
    return { action: 'botget', ok: true, appid: c.appid || '',
             hasSecret: !!s, secretMask: s ? (s.slice(0, 4) + '••••' + s.slice(-4)) : '',
             hasPubkey: !!c.pubkey }
  } else if (action === 'botset') {
    const aid = String((bodyObj && bodyObj.appid) || '').trim()
    const sec = String((bodyObj && bodyObj.secret) || '').trim()
    const puk = String((bodyObj && bodyObj.pubkey) || '').trim()
    const patch = {}
    if (aid) patch.appid = aid
    if (sec) patch.secret = sec
    if (puk) patch.pubkey = puk
    if (!Object.keys(patch).length) return { _status: 400, code: 400, msg: '至少填一项' }
    const w = await setBotCfg(patch)
    if (!w.ok) return { _status: 500, code: 500, msg: '写入失败：' + (w.msg || '') }
    return { action: 'botset', ok: true, saved: Object.keys(patch) }
  } else if (action === 'qqset') {
    /* 自定义口令（不想用随机串时） */
    const nt = String((bodyObj && bodyObj.newtoken) || '').trim()
    if (nt.length < 6) return { _status: 400, code: 400, msg: '班群口令至少 6 位' }
    if (/[\s]/.test(nt)) return { _status: 400, code: 400, msg: '口令里不要有空格' }
    const w2 = await setQqToken(nt)
    if (!w2.ok) return { _status: 500, code: 500, msg: '写入班群口令失败：' + (w2.msg || '') }
    return { action: 'qqset', ok: true, token: nt }
  } else {
    return { _status: 400, code: 400, msg: '未知动作' }
  }
  acc.salt = salt
  acc.note = '运行时口令配置。由管理员后台经云函数写入（token 不经过前端）。'

  const r = await ghPutFile(accPath, token, JSON.stringify(acc, null, 2), cur && cur.sha,
    'chore: 管理员更新全网口令')
  return { action: action, msg: msg, until: acc.until || 0, gh: r, acc_public: { lock: acc.lock, temp: acc.temp, until: acc.until } }
}

/* ==================== 入口 ==================== */
exports.main_handler = async (event) => {
  const path = String(event.path || '/').replace(/\/+$/, '') || '/'
  const method = String(event.httpMethod || 'GET').toUpperCase()
  const qs = parseQuery(event.queryString || '')
  let body = event.body || ''
  if (event.isBase64Encoded) {
    try { body = Buffer.from(body, 'base64').toString('utf8') } catch (e) { body = '' }
  }

  const ok = (obj, status) => ({
    statusCode: status || 200, headers: CORS,
    body: JSON.stringify(obj), isBase64Encoded: false,
  })
  const page = (html) => ({
    statusCode: 200, headers: HTML_HEADERS, body: html, isBase64Encoded: false,
  })

  try {
    if (method === 'OPTIONS') return { statusCode: 204, headers: CORS, body: '', isBase64Encoded: false }

    if (method !== 'GET' && (path === '/' || path === '/qq' || path === '/webhook')) {
      const r = await handleQQ(event, body, qs)
      if (r.plain_token !== undefined) return ok(r)          // 验证应答不带 _status
      return ok(r, r._status || 200)
    }
    if (method !== 'GET' && path.endsWith('/bot')) {
      /* 2026-10-08 新增：机器人接入接口 —— **不走管理员口令**，凭据即身份 */
      let b3 = null
      try { b3 = JSON.parse(body) } catch (e) { b3 = null }
      const act3 = qs.action || (b3 && b3.action) || ''
      const r3 = await botApi(act3, b3 || {})
      return ok(r3, r3._status || 200)
    }
    if (method !== 'GET' && path.endsWith('/admin')) {
      let b2 = null
      try { b2 = JSON.parse(body) } catch (e) { b2 = null }
      const act = qs.action || (b2 && b2.action) || ''
      const r = await adminApi(act, b2 || {})
      return ok(r, r._status || 200)
    }
    if (method !== 'GET' && path === '/sync') {
      const r = await handleSync(event, body)
      return ok(r, r._status || 200)
    }
    if (method !== 'GET') return ok({ code: 404, msg: '没有这个接口', path }, 404)

    if (path === '/probe') return ok(await probeRuntime())
    if (path === '/out') return ok(await probeOutbound())

    if (path === '/health') {
      let botN = 0
      try { botN = Object.keys((await loadBots()).bots || {}).length } catch (e) { botN = -1 }
      const allow = String(process.env.BOT_ALLOW_APPIDS || '').split(',').map(s => s.trim()).filter(Boolean)
      return ok({
        ok: true,
        /* owner 字段：让「设置 → 我的云函数」一眼认出这是谁家的函数 */
        owner: String(process.env.SITE_OWNER || ''),
        has_secret: !!process.env.BOT_SECRET,
        has_pubkey: !!process.env.PUBKEY,
        has_admin: !!process.env.ADMIN_TOKEN,
        has_read: !!process.env.READ_TOKEN,
        /* restricted=true 表示这台只服务白名单里的机器人 */
        restricted: allow.length > 0,
        bots: botN,
        node: process.version,
        now: Date.now(),
      })
    }

    if (path === '/dbg') {
      const t = qs.t || ''
      if (!(await qqAuthOk(t))) {
        return ok({ code: 401, msg: '口令不对' }, 401)
      }
      let sig = ''
      try { sig = await signHex('1730000000PROBETOKEN') } catch (e) { sig = 'ERR:' + String((e && e.message) || e) }
      let log = []
      try { log = JSON.parse(await KV().get('dbg') || '[]') } catch (e) { log = [] }
      return ok({
        has_secret: !!process.env.BOT_SECRET,
        secret_len: String(process.env.BOT_SECRET || '').length,
        has_pubkey: !!process.env.PUBKEY,
        probe_sig: sig,
        qq_index_len: (await readIndex('qq')).length,
        ann_index_len: (await readIndex('ann')).length,
        last_requests: log.slice(0, 5),
      })
    }

    const isAnn = path === '/ann'
    const isQq = path === '/qq' || (path === '/page' && qs.kind === 'qq')
    /* 2026-10-08：鉴权从「布尔口」升级为「带身份」——
       业主令牌 → 只回自己那份；管理员/老口令 → 看全部（等同站长视角）。 */
    let who = null
    if (isQq) {
      const t = qs.t || qs.token || ''
      who = await whoByAuth(t)
      if (!who) return ok({ code: 401, msg: '口令不对' }, 401)
    }
    if (!isAnn && !isQq && path !== '/page') {
      return page('<!doctype html><meta charset="utf-8"><title>蛇杖二号</title>' +
        '<body style="font:15px/1.8 -apple-system,\'PingFang SC\',sans-serif;padding:30px;max-width:640px">' +
        '<h2>蛇杖二号</h2><ul><li><a href="/page?kind=ann">公告（公开）</a></li>' +
        '<li><a href="/page?kind=qq&t=你的令牌">班群消息（用你的机器人令牌）</a></li>' +
        '<li><a href="/health">健康自检</a></li></ul></body>')
    }

    const kind = isQq ? 'qq' : 'ann'
    /* 业主只取自己 appid 的那份摘要；管理员/老口令取全部（老行为） */
    const scopeAppid = (who && who.role === 'owner') ? who.appid : ''
    const items = await listItems(kind, Math.min(Number(qs.limit) || 200, 200), scopeAppid)
    if (path === '/page') {
      return page(pageHtml(items,
        kind === 'qq' ? '蛇杖二号 · 班群消息' : '蛇杖二号 · 公告',
        kind === 'qq' ? '只给你看 · 已脱敏' : '公开 · 可转给同学'))
    }
    return {
      statusCode: 200,
      /* 2026-10-07：班群消息也开跨域 —— 页面要在站内直接读、不再新开网页。
         请注意：**安全性由 token 承担**（无正确口令一律 401），不是靠藏 CORS。 */
      headers: CORS,
      /* items 本来就带 id（发布时写入），这里原样返回，页面靠它做勾选删除 */
      body: JSON.stringify({ count: items.length, items, ts: Date.now() }),
      isBase64Encoded: false,
    }
  } catch (e) {
    return ok({ code: 500, msg: '函数异常', err: String((e && e.message) || e) }, 500)
  }
}

exports._setKV = setKV
exports._mem = _mem
/* 上传相关内部函数开放出来给自检脚本用（_selftest_upload.mjs）：
   主要是验「二进制 base64 不再被 utf8 二次编码」这条老坑。 */
exports._upPut = upPut
exports._upList = upList
exports._safeName = safeName
exports._ghPutFile = ghPutFile
/* 2026-10-08 新增：机器人接入相关（_selftest_bot.mjs 用） */
exports._loadBots = loadBots
exports._saveBots = saveBots
exports._botApi = botApi
exports._whoByAuth = whoByAuth
exports._whoByToken = whoByToken
exports._qqPathOf = qqPathOf
exports._maskSecret = maskSecret
